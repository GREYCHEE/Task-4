import React, { useState } from "react";
import { UserProvider } from "./context/UserContext";
import UserForm from "./components/UserForm";
import UserList from "./components/UserList";
import { Container } from "@mui/material";

const App = () => {
  const [editingIndex, setEditingIndex] = useState(null);

  return (
    <UserProvider>
      <Container>
        <UserForm editingIndex={editingIndex} setEditingIndex={setEditingIndex} />
     
        <UserList setEditingIndex={setEditingIndex} />
      </Container>
    </UserProvider>
  );
};
   



export default App;

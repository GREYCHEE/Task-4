import React, { useState, useContext, useEffect, useMemo } from "react";
import { TextField, Button, Radio, RadioGroup, FormControlLabel, Checkbox, Select, MenuItem, Card, CardContent, Typography } from "@mui/material";
import { UserContext } from "../context/UserContext";

const UserForm = ({ editingIndex, setEditingIndex }) => {
  const { users, addUser, updateUser } = useContext(UserContext);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    gender: "male",
    agree: false,
    date: "",
    dropdown: "",
  });

  useEffect(() => {
    if (editingIndex !== null) setFormData(users[editingIndex]);
  }, [editingIndex, users]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const isFormValid = useMemo(() => {
    return formData.name && formData.email && formData.password && formData.date;
  }, [formData]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isFormValid) {
      alert("Please fill all required fields");
      return;
    }

    if (editingIndex !== null) {
      updateUser(editingIndex, formData);
      setEditingIndex(null);
    } else {
      addUser(formData);
    }

    setFormData({ name: "", email: "", password: "", gender: "male", agree: false, date: "", dropdown: "" });
  };

  return (
    <Card sx={{ maxWidth: 500, margin: "auto", padding: 3, boxShadow: 3 }}>
      <CardContent>
        <Typography variant="h5" textAlign="center" marginBottom={2}>
          {editingIndex !== null ? "Update User" : "Add User"}
        </Typography>
        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
          <TextField label="Name" name="name" value={formData.name} onChange={handleChange} required fullWidth />
          <TextField label="Email" type="email" name="email" value={formData.email} onChange={handleChange} required fullWidth />
          <TextField label="Password" type="password" name="password" value={formData.password} onChange={handleChange} required fullWidth />

          <RadioGroup row name="gender" value={formData.gender} onChange={handleChange}>
            <FormControlLabel value="male" control={<Radio />} label="Male" />
            <FormControlLabel value="female" control={<Radio />} label="Female" />
          </RadioGroup>

          <FormControlLabel control={<Checkbox name="agree" checked={formData.agree} onChange={handleChange} />} label="Agree to Terms" />

          <TextField fullWidth type="date" name="date" value={formData.date} onChange={handleChange} required />

          <Select fullWidth name="dropdown" value={formData.dropdown} onChange={handleChange}>
            <MenuItem value="option1">Option 1</MenuItem>
            <MenuItem value="option2">Option 2</MenuItem>
          </Select>

          <Button type="submit" variant="contained" color="primary" fullWidth disabled={!isFormValid}>
            {editingIndex !== null ? "Update User" : "Add User"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default UserForm;

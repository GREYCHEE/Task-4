import React, { useContext } from "react";
import { Button, Card, CardContent, Typography } from "@mui/material";
import { UserContext } from "../context/UserContext";

const UserList = ({ setEditingIndex }) => {
  const { users, deleteUser } = useContext(UserContext);

  return (
    <div style={{ maxWidth: 500, margin: "auto", marginTop: 20 }}>
      <Typography variant="h5" textAlign="center">User List</Typography>
      {users.length > 0 ? (
        users.map((user, index) => (
          <Card key={index} sx={{ marginTop: 2, padding: 2, boxShadow: 2 }}>
            <CardContent>
              <Typography><b>Name:</b> {user.name}</Typography>
              <Typography><b>Email:</b> {user.email}</Typography>
              <Button variant="contained" color="secondary" onClick={() => setEditingIndex(index)} sx={{ marginRight: 1 }}>
                Edit
              </Button>
              <Button variant="contained" color="error" onClick={() => deleteUser(index)}>
                Delete
              </Button>
            </CardContent>
          </Card>
        ))
      ) : (
        <Typography textAlign="center">No users added</Typography>
      )}
    </div>
  );
};

export default UserList;

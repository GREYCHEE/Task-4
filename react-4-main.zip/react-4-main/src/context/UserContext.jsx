import React, { createContext, useState, useEffect, useCallback } from "react";

export const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const storedUsers = JSON.parse(localStorage.getItem("users")) || [];
    setUsers(storedUsers);
  }, []);

  useEffect(() => {
    localStorage.setItem("users", JSON.stringify(users));
  }, [users]);

  const addUser = useCallback((user) => {
    setUsers((prevUsers) => [...prevUsers, user]);
  }, []);

  const updateUser = useCallback((index, updatedUser) => {
    setUsers((prevUsers) => {
      const newUsers = [...prevUsers];
      newUsers[index] = updatedUser;
      return newUsers;
    });
  }, []);

  const deleteUser = useCallback((index) => {
    setUsers((prevUsers) => prevUsers.filter((_, i) => i !== index));
  }, []);

  return (
    <UserContext.Provider value={{ users, addUser, updateUser, deleteUser }}>
      {children}
    </UserContext.Provider>
  );
};
